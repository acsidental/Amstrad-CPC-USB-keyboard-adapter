/*
  Amstrad CPC 464 USB keyboard adapter
  Hardware: Raspberry Pi Pico + 1 x MT8816 + 1 x 4066

  CPC 464 connector matrix:
    ROWS:
      O/1  = pin 1
      O/2  = pin 11
      O/3  = pin 12
      O/4  = pin 13
      O/5  = pin 14
      O/6  = pin 15
      O/7  = pin 16
      O/8  = pin 17
      O/9  = pin 18
      O/10 = pin 19

    COLUMNS:
      C1 = pin 2   (DEL only)
      C2 = pin 3
      C3 = pin 4
      C4 = pin 5
      C5 = pin 6
      C6 = pin 7
      C7 = pin 8
      C8 = pin 9
      C9 = pin 10

  MT8816:
      X0..X9 = O/1..O/10
      Y0..Y7 = CPC pins 3..10

  4066:
      one switch = CPC pin 1 (O/1) <-> CPC pin 2
      This is DEL.

  IMPORTANT:
    - The Pico NEVER drives CPC matrix rows/columns.
    - MT8816 X/Y pins are analogue/bilateral switch terminals.
    - Prefer 74HCT4066 when the switch is powered at 5 V, because
      the Pico control signal is 3.3 V.
    - Set Arduino-Pico CPU speed to 120 MHz or 240 MHz for PIO USB.
    - MT8816 CS and RESET are both ACTIVE HIGH (confirmed against the
      Mitel/Zarlink datasheet) - the sequencing below is correct as-is.

  CHANGES vs the original version:
    1. Several CPC-specific keys (@, GBP, +, *, ?, >, CLR, COPY, and
       the numeric-keypad ENTER) were defined as matrix positions but
       never wired up to any USB HID keycode, so they could never be
       typed. HID mappings have been added for all of them below.
       The exact HID keycodes chosen are a reasonable guess (aimed at
       a UK-style physical layout) - change them freely to match
       whatever keyboard you actually plug in.
    2. The code assumed the USB keyboard is operating in USB HID
       "Boot Protocol" (the fixed 8-byte report format) without ever
       requesting it. It now explicitly calls tuh_hid_set_protocol()
       to force Boot Protocol, and only starts pulling reports once
       that's confirmed (falling back gracefully if the request is
       rejected).
    3. setup() (core 0, configures the MT8816/4066 GPIOs) and
       setup1()/loop1() (core 1, runs the USB host and can invoke the
       HID report callback) run concurrently on the RP2040. Nothing
       previously stopped a HID report from driving those GPIOs
       before they were configured as outputs. A hw_ready flag now
       gates all matrix writes until setup() has finished.

  Library setup:
    This sketch uses Adafruit's USBH host wrapper:
      #include "Adafruit_USBH_Host.h"

    If Arduino reports that USBHost is not declared, make sure the
    Adafruit TinyUSB library installed in Documents/Arduino/libraries
    is not an old duplicate that shadows the RP2040 package library.
*/

#include <Arduino.h>
#include <hardware/clocks.h>
#include "pio_usb.h"
#include "Adafruit_TinyUSB.h"
#include "Adafruit_USBH_Host.h"
#include "tusb.h"

// ---------------- GPIO ----------------
#define MT_DATA       2
#define MT_STROBE     3
#define MT_CS         4
#define MT_RESET     13

#define DEL_SWITCH    12

static const uint8_t AX_PINS[4] = {5, 6, 7, 8};   // AX0..AX3
// AY0..AY2. NOTE: indices 1 and 2 were swapped from the "obvious"
// {9,10,11} order. Bench testing showed the Y-address bits 1 and 2
// were transposed (e.g. pressing A produced Q, D produced W, H
// produced U - always a clean swap of those two bits), which is the
// classic symptom of AY1/AY2 being crossed between the Pico and the
// MT8816. If your board is wired the "obvious" way and this makes
// things worse instead of better, put it back to {9, 10, 11} and the
// real fault is elsewhere (e.g. AX bits instead of AY).
static const uint8_t AY_PINS[3] = {9, 11, 10};

#define HOST_PIN_DP 21                              // D- is +1 = GP22

// ---------------- USB host ----------------
Adafruit_USBH_Host USBHost;

// ---------------- Startup / cross-core readiness ----------------
// setup() runs on core 0, setup1()/loop1() run on core 1. USB HID
// callbacks fire from core 1 and can happen while core 0 is still
// mid-way through configuring the MT8816/4066 GPIOs. This flag is
// only set true once setup() has finished all pin configuration, and
// every matrix write checks it first.
static volatile bool hw_ready = false;

// ---------------- Matrix ----------------
// row 0..9 = O/1..O/10
// col 0 = CPC pin 2 (DEL / 4066)
// col 1..8 = CPC pins 3..10 (MT8816 Y0..Y7)

struct MatrixKey {
  uint8_t row;
  uint8_t col;
};

#define KEY(r,c) MatrixKey{(uint8_t)(r),(uint8_t)(c)}
static const MatrixKey INVALID = {255,255};

static bool valid(MatrixKey k) {
  return k.row < 12 && k.col < 9;
}

static bool matrix_state[12][9] = {};

// ---------------- MT8816 ----------------
// Set to 1 to print every logical (row,col) -> electrical (x,y)
// translation over Serial, to cross-check against a multimeter /
// continuity test on the actual AX/AY wiring while debugging.
#define MATRIX_DEBUG 0

static void mt8816_write(uint8_t row, uint8_t col, bool on)
{
  // col 1..8 correspond to MT8816 Y0..Y7.
  if (row >= 12 || col < 1 || col > 8) return;

  const uint8_t x = row;       // X0..X9
  const uint8_t y = col - 1;   // Y0..Y7

#if MATRIX_DEBUG
  Serial.printf("mt8816_write row=%u col=%u -> X=%u Y=%u %s\n",
                row, col, x, y, on ? "ON" : "off");
#endif

  for (uint8_t i = 0; i < 4; ++i)
    digitalWrite(AX_PINS[i], (x >> i) & 1);

  for (uint8_t i = 0; i < 3; ++i)
    digitalWrite(AY_PINS[i], (y >> i) & 1);

  digitalWrite(MT_DATA, on ? HIGH : LOW);

  // MT8816 CS and STROBE are both active HIGH. Data is written
  // whenever CS and STROBE are both high, latched on the falling
  // edge of STROBE. Address/data must be stable before that edge.
  digitalWrite(MT_CS, HIGH);
  delayMicroseconds(1);

  digitalWrite(MT_STROBE, HIGH);
  delayMicroseconds(1);
  digitalWrite(MT_STROBE, LOW);

  digitalWrite(MT_CS, LOW);
}

static void cpc_set_key(uint8_t row, uint8_t col, bool pressed)
{
  if (row >= 12 || col >= 9) return;

  if (col == 0) {
    // DEL: CPC pin 1 <-> CPC pin 2 through 4066.
    digitalWrite(DEL_SWITCH, pressed ? HIGH : LOW);
  } else {
    mt8816_write(row, col, pressed);
  }
}

static void release_all_keys()
{
  if (!hw_ready) return;

  for (uint8_t r = 0; r < 12; ++r) {
    for (uint8_t c = 0; c < 9; ++c) {
      if (matrix_state[r][c]) {
        matrix_state[r][c] = false;
        cpc_set_key(r, c, false);
      }
    }
  }
  digitalWrite(DEL_SWITCH, LOW);
}

static void set_key(MatrixKey k, bool pressed)
{
  if (!hw_ready) return;
  if (!valid(k)) return;
  if (matrix_state[k.row][k.col] == pressed) return;

  matrix_state[k.row][k.col] = pressed;
  cpc_set_key(k.row, k.col, pressed);
}

// ---------------- CPC physical key map ----------------
// Coordinates are from the supplied matrix drawing.
//
// Columns are:
//   0=pin2, 1=pin3, 2=pin4, 3=pin5, 4=pin6,
//   5=pin7, 6=pin8, 7=pin9, 8=pin10

static const MatrixKey K_DEL    = KEY(0,0);

static const MatrixKey K_1      = KEY(1,1);
static const MatrixKey K_2      = KEY(1,2);
static const MatrixKey K_TAB    = KEY(1,3);
static const MatrixKey K_A      = KEY(1,4);
static const MatrixKey K_ESC    = KEY(1,5);
static const MatrixKey K_Q      = KEY(1,6);
static const MatrixKey K_CAPS   = KEY(1,7);
static const MatrixKey K_Z      = KEY(1,8);

static const MatrixKey K_4      = KEY(2,1);
static const MatrixKey K_3      = KEY(2,2);
static const MatrixKey K_S      = KEY(2,3);
static const MatrixKey K_D      = KEY(2,4);
static const MatrixKey K_E      = KEY(2,5);
static const MatrixKey K_W      = KEY(2,6);
static const MatrixKey K_C      = KEY(2,7);
static const MatrixKey K_X      = KEY(2,8);

static const MatrixKey K_6      = KEY(3,1);
static const MatrixKey K_5      = KEY(3,2);
static const MatrixKey K_G      = KEY(3,3);
static const MatrixKey K_F      = KEY(3,4);
static const MatrixKey K_R      = KEY(3,5);
static const MatrixKey K_T      = KEY(3,6);
static const MatrixKey K_B      = KEY(3,7);
static const MatrixKey K_V      = KEY(3,8);

static const MatrixKey K_8      = KEY(4,1);
static const MatrixKey K_7      = KEY(4,2);
static const MatrixKey K_H      = KEY(4,3);
static const MatrixKey K_J      = KEY(4,4);
static const MatrixKey K_U      = KEY(4,5);
static const MatrixKey K_Y      = KEY(4,6);
static const MatrixKey K_N      = KEY(4,7);
static const MatrixKey K_SPACE  = KEY(4,8);

static const MatrixKey K_0      = KEY(5,1);
static const MatrixKey K_9      = KEY(5,2);
static const MatrixKey K_L      = KEY(5,3);
static const MatrixKey K_K      = KEY(5,4);
static const MatrixKey K_O      = KEY(5,5);
static const MatrixKey K_I      = KEY(5,6);
static const MatrixKey K_M      = KEY(5,7);
static const MatrixKey K_COMMA  = KEY(5,8);

static const MatrixKey K_POUND  = KEY(8,1);
static const MatrixKey K_EQUAL  = KEY(8,2);
static const MatrixKey K_PLUS   = KEY(8,3);
static const MatrixKey K_STAR   = KEY(8,4);
static const MatrixKey K_AT     = KEY(8,5);
static const MatrixKey K_P      = KEY(8,6);
static const MatrixKey K_SLASH  = KEY(8,7);
static const MatrixKey K_DOT    = KEY(8,8);

static const MatrixKey K_CLR    = KEY(9,1);
static const MatrixKey K_LBRACK = KEY(9,2);
static const MatrixKey K_KP4    = KEY(9,3);
static const MatrixKey K_SHIFT  = KEY(9,4);
static const MatrixKey K_RETURN = KEY(9,5);
static const MatrixKey K_RBRACK = KEY(9,6);
static const MatrixKey K_BSLASH = KEY(9,7);
static const MatrixKey K_CTRL   = KEY(9,8);

static const MatrixKey K_LEFT   = KEY(10,1);
static const MatrixKey K_COPY   = KEY(10,2);
static const MatrixKey K_KP5    = KEY(10,3);
static const MatrixKey K_KP1    = KEY(10,4);
static const MatrixKey K_KP7    = KEY(10,5);
static const MatrixKey K_KP8    = KEY(10,6);
static const MatrixKey K_KP2    = KEY(10,7);
static const MatrixKey K_KP0    = KEY(10,8);

static const MatrixKey K_UP     = KEY(11,1);
static const MatrixKey K_RIGHT  = KEY(11,2);
static const MatrixKey K_KP6   = KEY(11,3);
static const MatrixKey K_KP3    = KEY(11,4);
static const MatrixKey K_DOWN    = KEY(11,5);
static const MatrixKey K_KP9    = KEY(11,6);
static const MatrixKey K_ENTER2 = KEY(11,7);
static const MatrixKey K_KPDOT  = KEY(11,8);

// ---------------- HID -> CPC ----------------
static MatrixKey matrix_for_hid(uint8_t kc)
{
  switch (kc) {
    case HID_KEY_A: return K_A;
    case HID_KEY_B: return K_B;
    case HID_KEY_C: return K_C;
    case HID_KEY_D: return K_D;
    case HID_KEY_E: return K_E;
    case HID_KEY_F: return K_F;
    case HID_KEY_G: return K_G;
    case HID_KEY_H: return K_H;
    case HID_KEY_I: return K_I;
    case HID_KEY_J: return K_J;
    case HID_KEY_K: return K_K;
    case HID_KEY_L: return K_L;
    case HID_KEY_M: return K_M;
    case HID_KEY_N: return K_N;
    case HID_KEY_O: return K_O;
    case HID_KEY_P: return K_P;
    case HID_KEY_Q: return K_Q;
    case HID_KEY_R: return K_R;
    case HID_KEY_S: return K_S;
    case HID_KEY_T: return K_T;
    case HID_KEY_U: return K_U;
    case HID_KEY_V: return K_V;
    case HID_KEY_W: return K_W;
    case HID_KEY_X: return K_X;
    case HID_KEY_Y: return K_Y;
    case HID_KEY_Z: return K_Z;

    case HID_KEY_1: return K_1;
    case HID_KEY_2: return K_2;
    case HID_KEY_3: return K_3;
    case HID_KEY_4: return K_4;
    case HID_KEY_5: return K_5;
    case HID_KEY_6: return K_6;
    case HID_KEY_7: return K_7;
    case HID_KEY_8: return K_8;
    case HID_KEY_9: return K_9;
    case HID_KEY_0: return K_0;

    case HID_KEY_ESCAPE:        return K_ESC;
    case HID_KEY_TAB:           return K_TAB;
    case HID_KEY_SPACE:         return K_SPACE;
    case HID_KEY_BACKSPACE:     return K_DEL;
    case HID_KEY_CAPS_LOCK:     return K_CAPS;
    case HID_KEY_ENTER:        return K_RETURN;

    case HID_KEY_ARROW_LEFT:    return K_LEFT;
    case HID_KEY_ARROW_RIGHT:   return K_RIGHT;
    case HID_KEY_ARROW_UP:      return K_UP;
    case HID_KEY_ARROW_DOWN:    return K_DOWN;

    case HID_KEY_COMMA:         return K_COMMA;
    case HID_KEY_PERIOD:        return K_DOT;
    case HID_KEY_MINUS:         return K_EQUAL;
    case HID_KEY_BRACKET_LEFT:  return K_LBRACK;
    case HID_KEY_BRACKET_RIGHT: return K_RBRACK;
    case HID_KEY_BACKSLASH:     return K_BSLASH;

    // --- Previously-missing CPC keys. Adjust these HID keycodes to
    // taste - they were unreachable before because nothing in this
    // switch referenced them.
    case HID_KEY_APOSTROPHE:         return K_AT;       // ` key -> @
    case HID_KEY_NUM_LOCK:      return K_POUND;    // ISO key near Enter -> GBP
    case HID_KEY_EUROPE_2:      return K_SLASH;  // ISO key near L-Shift -> >
    case HID_KEY_SLASH:         return K_SLASH; // / key -> ?
    case HID_KEY_EQUAL:    return K_PLUS;
    case HID_KEY_SEMICOLON:         return K_STAR;
    case HID_KEY_KEYPAD_ENTER:    return K_ENTER2;
    case HID_KEY_DELETE:        return K_CLR;      // forward-Delete -> CLR
    case HID_KEY_INSERT:        return K_COPY;     // Insert -> COPY

    case HID_KEY_KEYPAD_1: return K_KP1;
    case HID_KEY_KEYPAD_2: return K_KP2;
    case HID_KEY_KEYPAD_3: return K_KP3;
    case HID_KEY_KEYPAD_4: return K_KP4;
    case HID_KEY_KEYPAD_5: return K_KP5;
    case HID_KEY_KEYPAD_6: return K_KP6;
    case HID_KEY_KEYPAD_7: return K_KP7;
    case HID_KEY_KEYPAD_8: return K_KP8;
    case HID_KEY_KEYPAD_9: return K_KP9;
    case HID_KEY_KEYPAD_0: return K_KP0;
    case HID_KEY_KEYPAD_DECIMAL:  return K_KPDOT;
    case HID_KEY_KEYPAD_DIVIDE:  return K_SLASH;
    case HID_KEY_KEYPAD_MULTIPLY: return K_STAR;
    case HID_KEY_KEYPAD_SUBTRACT:  return K_EQUAL;
    case HID_KEY_KEYPAD_ADD: return K_PLUS;

    default: return INVALID;
  }
}

// ---------------- HID report handling ----------------
static hid_keyboard_report_t previous_report = {};

static bool report_has(uint8_t const *codes, uint8_t kc)
{
  for (uint8_t i=0; i<6; ++i)
    if (codes[i] == kc) return true;
  return false;
}

static void update_modifiers(uint8_t modifiers)
{
  bool shift = modifiers & (KEYBOARD_MODIFIER_LEFTSHIFT |
                            KEYBOARD_MODIFIER_RIGHTSHIFT);
  bool ctrl  = modifiers & (KEYBOARD_MODIFIER_LEFTCTRL |
                            KEYBOARD_MODIFIER_RIGHTCTRL);

  set_key(K_SHIFT, shift);
  set_key(K_CTRL, ctrl);
}

static void process_report(hid_keyboard_report_t const *r)
{
  if (!hw_ready) return;

  for (uint8_t i=0; i<6; ++i) {
    uint8_t oldkc = previous_report.keycode[i];
    if (oldkc && !report_has(r->keycode, oldkc))
      set_key(matrix_for_hid(oldkc), false);
  }

  for (uint8_t i=0; i<6; ++i) {
    uint8_t newkc = r->keycode[i];
    if (newkc && !report_has(previous_report.keycode, newkc))
      set_key(matrix_for_hid(newkc), true);
  }

  update_modifiers(r->modifier);
  previous_report = *r;
}

// ---------------- TinyUSB callbacks ----------------
extern "C" void tuh_hid_mount_cb(uint8_t dev_addr,
                                  uint8_t instance,
                                  uint8_t const *desc_report,
                                  uint16_t desc_len)
{
  (void)desc_report;
  (void)desc_len;

  Serial.printf("HID mounted: addr=%u instance=%u\n", dev_addr, instance);

  if (tuh_hid_interface_protocol(dev_addr, instance) ==
      HID_ITF_PROTOCOL_KEYBOARD) {
    // Force Boot Protocol so the reports we get back always match the
    // fixed 8-byte hid_keyboard_report_t layout this code assumes.
    // tuh_hid_set_protocol_complete_cb() below starts the report
    // stream once this is confirmed. If the device rejects the
    // request (returns false), fall back to requesting reports
    // directly - some keyboards already boot in Boot Protocol and
    // don't support/need the explicit SET_PROTOCOL request.
    if (!tuh_hid_set_protocol(dev_addr, instance, HID_PROTOCOL_BOOT)) {
      if (!tuh_hid_receive_report(dev_addr, instance))
        Serial.println("Failed to request keyboard report");
    }
  }
}

extern "C" void tuh_hid_set_protocol_complete_cb(uint8_t dev_addr,
                                                  uint8_t instance,
                                                  uint8_t protocol)
{
  if (protocol == HID_PROTOCOL_BOOT) {
    if (!tuh_hid_receive_report(dev_addr, instance))
      Serial.println("Failed to request keyboard report");
  }
}

extern "C" void tuh_hid_umount_cb(uint8_t dev_addr, uint8_t instance)
{
  Serial.printf("HID unmounted: addr=%u instance=%u\n", dev_addr, instance);
  previous_report = {};
  release_all_keys();
}

extern "C" void tuh_hid_report_received_cb(uint8_t dev_addr,
                                            uint8_t instance,
                                            uint8_t const *report,
                                            uint16_t len)
{
  if (tuh_hid_interface_protocol(dev_addr, instance) ==
      HID_ITF_PROTOCOL_KEYBOARD) {
    if (len >= sizeof(hid_keyboard_report_t))
      process_report((hid_keyboard_report_t const *)report);
  }

  tuh_hid_receive_report(dev_addr, instance);
}

// ---------------- Setup ----------------
void setup()
{
  Serial.begin(115200);
  delay(1000);

  pinMode(MT_DATA, OUTPUT);
  pinMode(MT_STROBE, OUTPUT);
  pinMode(MT_CS, OUTPUT);
  pinMode(MT_RESET, OUTPUT);
  pinMode(DEL_SWITCH, OUTPUT);

  for (uint8_t i=0; i<4; ++i) pinMode(AX_PINS[i], OUTPUT);
  for (uint8_t i=0; i<3; ++i) pinMode(AY_PINS[i], OUTPUT);

  digitalWrite(MT_DATA, LOW);
  digitalWrite(MT_STROBE, LOW);
  digitalWrite(MT_CS, LOW);
  digitalWrite(DEL_SWITCH, LOW);

  // MT8816 reset is active HIGH.
  digitalWrite(MT_RESET, HIGH);
  delayMicroseconds(10);
  digitalWrite(MT_RESET, LOW);

  // All GPIOs are configured and the MT8816 has been hardware-reset.
  // Only now is it safe for core 1's USB callbacks to start driving
  // the matrix.
  hw_ready = true;

  release_all_keys();

  Serial.println("CPC 464 USB matrix controller");
}

void setup1()
{
  uint32_t hz = clock_get_hz(clk_sys);
  if (hz != 120000000UL && hz != 240000000UL) {
    Serial.printf("PIO USB requires 120/240 MHz; CPU=%lu\n",
                  (unsigned long)hz);
    return;
  }

  pio_usb_configuration_t cfg = PIO_USB_DEFAULT_CONFIG;
  cfg.pin_dp = HOST_PIN_DP;

  USBHost.configure_pio_usb(1, &cfg);
  USBHost.begin(1);

  Serial.println("PIO USB host started");
}

void loop1()
{
  USBHost.task();
}

void loop()
{
  delay(1);
}
