#include "pio_usb.h"
#include "Adafruit_TinyUSB.h"

#define HOST_PIN_DP   21
#define HOST_PIN_DM   22

// --- TRUE 10x9 PHYSICAL MATRIX MAPPING ---
// Explicitly using GPIO 0-9 for inputs and GPIO 10-18 for outputs to allow bitmasking
const uint8_t cpcLines[] = {0, 1, 2, 3, 4, 5, 6, 7, 8, 9};       // 10 Scanning inputs from CPC
const uint8_t cpcBits[]  = {10, 11, 12, 13, 14, 15, 16, 17, 18}; // 9 Data return outputs to CPC

Adafruit_USBH_Host USBHost;

// True physical 10-line by 9-column tracking matrix buffer [Rows][Columns]
volatile bool keyMatrix[10][9] = {false};

void process_kbd_report(hid_keyboard_report_t const *report) {
  memset((void*)keyMatrix, 0, sizeof(keyMatrix));

  for(uint8_t i = 0; i < 6; i++) {
    uint8_t code = report->keycode[i];
    if (code == 0) continue;

    switch(code) {
      // --- LINE 0 ---
      case 0x2A: keyMatrix[0][0] = true; break; // Backspace

      // --- LINE 1 ---
      case 0x1E: keyMatrix[1][1] = true; break; // 1
      case 0x1F: keyMatrix[1][2] = true; break; // 2
      case 0x29: keyMatrix[1][3] = true; break; // ESC
      case 0x14: keyMatrix[1][4] = true; break; // Q
      case 0x2B: keyMatrix[1][5] = true; break; // TAB
      case 0x04: keyMatrix[1][6] = true; break; // A
      case 0x39: keyMatrix[1][7] = true; break; // Caps Lock
      case 0x1D: keyMatrix[1][8] = true; break; // Z

      // --- LINE 2 ---
      case 0x21: keyMatrix[2][1] = true; break; // 4
      case 0x20: keyMatrix[2][2] = true; break; // 3
      case 0x08: keyMatrix[2][3] = true; break; // E
      case 0x1A: keyMatrix[2][4] = true; break; // W
      case 0x16: keyMatrix[2][5] = true; break; // S
      case 0x07: keyMatrix[2][6] = true; break; // D
      case 0x06: keyMatrix[2][7] = true; break; // C
      case 0x1B: keyMatrix[2][8] = true; break; // X

      // --- LINE 3 ---
      case 0x23: keyMatrix[3][1] = true; break; // 6
      case 0x22: keyMatrix[3][2] = true; break; // 5
      case 0x15: keyMatrix[3][3] = true; break; // R
      case 0x17: keyMatrix[3][4] = true; break; // T
      case 0x0A: keyMatrix[3][5] = true; break; // G
      case 0x09: keyMatrix[3][6] = true; break; // F
      case 0x05: keyMatrix[3][7] = true; break; // B
      case 0x19: keyMatrix[3][8] = true; break; // V

      // --- LINE 4 ---
      case 0x25: keyMatrix[4][1] = true; break; // 8
      case 0x24: keyMatrix[4][2] = true; break; // 7
      case 0x18: keyMatrix[4][3] = true; break; // U
      case 0x1C: keyMatrix[4][4] = true; break; // Y
      case 0x0B: keyMatrix[4][5] = true; break; // H
      case 0x0D: keyMatrix[4][6] = true; break; // J
      case 0x11: keyMatrix[4][7] = true; break; // N
      case 0x2C: keyMatrix[4][8] = true; break; // Space

      // --- LINE 5 ---
      case 0x27: keyMatrix[5][1] = true; break; // 0
      case 0x26: keyMatrix[5][2] = true; break; // 9
      case 0x12: keyMatrix[5][3] = true; break; // O
      case 0x0C: keyMatrix[5][4] = true; break; // I
      case 0x0E: keyMatrix[5][5] = true; break; // L
      case 0x0F: keyMatrix[5][6] = true; break; // K
      case 0x10: keyMatrix[5][7] = true; break; // M
      case 0x36: keyMatrix[5][8] = true; break; // ,

      // --- LINE 6 ---
      case 0x2F: keyMatrix[6][0] = true; break; // [
      case 0x30: keyMatrix[6][1] = true; break; // ]
      case 0x28: keyMatrix[6][2] = true; break; // Return
      case 0x34: keyMatrix[6][3] = true; break; // '
      case 0x33: keyMatrix[6][4] = true; break; // ;
      case 0x37: keyMatrix[6][5] = true; break; // .
      case 0x38: keyMatrix[6][6] = true; break; // /
      case 0x2D: keyMatrix[6][7] = true; break; // -

      // --- LINE 7 ---
      case 0x3A: keyMatrix[7][0] = true; break; // F1
      case 0x3B: keyMatrix[7][1] = true; break; // F2
      case 0x3C: keyMatrix[7][2] = true; break; // F3
      case 0x5C: keyMatrix[7][3] = true; break; // Numpad *
      case 0x56: keyMatrix[7][4] = true; break; // Numpad -
      case 0x57: keyMatrix[7][5] = true; break; // Numpad +
      case 0x3D: keyMatrix[7][6] = true; break; // F4
      case 0xE0: keyMatrix[7][7] = true; break; // Left Ctrl

      // --- LINE 8 ---
      case 0x43: keyMatrix[8][0] = true; break; // F10
      case 0x50: keyMatrix[8][1] = true; break; // Left Arrow
      case 0x3E: keyMatrix[8][2] = true; break; // F5
      case 0x5F: keyMatrix[8][3] = true; break; // Numpad 7
      case 0x60: keyMatrix[8][4] = true; break; // Numpad 8
      case 0x5D: keyMatrix[8][5] = true; break; // Numpad 5
      case 0x59: keyMatrix[8][6] = true; break; // Numpad 1
      case 0x5A: keyMatrix[8][7] = true; break; // Numpad 2
      case 0x62: keyMatrix[8][8] = true; break; // Numpad 0

      // --- LINE 9 ---
      case 0x52: keyMatrix[9][0] = true; break; // Up Arrow
      case 0x4F: keyMatrix[9][1] = true; break; // Right Arrow
      case 0x51: keyMatrix[9][2] = true; break; // Down Arrow
      case 0x61: keyMatrix[9][3] = true; break; // Numpad 9
      case 0x5E: keyMatrix[9][4] = true; break; // Numpad 6
      case 0x5B: keyMatrix[9][5] = true; break; // Numpad 3
      case 0x58: keyMatrix[9][6] = true; break; // Numpad Enter
      case 0x63: keyMatrix[9][7] = true; break; // Numpad .
    }
  }

  uint8_t modifiers = report->modifier;
  if (modifiers & (KEYBOARD_MODIFIER_LEFTSHIFT | KEYBOARD_MODIFIER_RIGHTSHIFT)) {
    keyMatrix[7][8] = true; // Maps Shift to Row 7, Col 8
  }
}

extern "C" {
  void tuh_hid_keyboard_report_received_cb(uint8_t dev_addr, hid_keyboard_report_t const *report) {
    process_kbd_report(report);
  }
}

// CORE 0: Dedicated to USB Stack Tasks
void setup() {
  pio_usb_configuration_t pio_cfg = PIO_USB_DEFAULT_CONFIG;
  pio_cfg.pin_dp = HOST_PIN_DP; 
  USBHost.configure_pio_usb(1, &pio_cfg); 
  USBHost.begin(1);
}

void loop() { 
  USBHost.task(); 
}

// CORE 1: Dedicated to Ultra-Fast Polling
void setup1() {
  for (int i = 0; i < 10; i++) {
    pinMode(cpcLines[i], INPUT_PULLUP);
  }
  for (int i = 0; i < 9; i++) {
    pinMode(cpcBits[i], INPUT);
    digitalWrite(cpcBits[i], LOW); 
  }
}

void loop1() {
  // Read all GPIO states at once (Pins 0 to 29)
  uint32_t current_gpio = gpio_get_all();

  // Create a combined 9-pin output direction configuration mask
  uint32_t target_directions_mask = 0;

  // Evaluate matching bits against active low scan lines
  if ((current_gpio & (1 << 0)) == 0) { // Line 0 is LOW
    for(int b=0; b<9; b++) if(keyMatrix[0][b]) target_directions_mask |= (1 << (10 + b));
  }
  if ((current_gpio & (1 << 1)) == 0) { // Line 1 is LOW
    for(int b=0; b<9; b++) if(keyMatrix[1][b]) target_directions_mask |= (1 << (10 + b));
  }
  if ((current_gpio & (1 << 2)) == 0) { // Line 2 is LOW
    for(int b=0; b<9; b++) if(keyMatrix[2][b]) target_directions_mask |= (1 << (10 + b));
  }
  if ((current_gpio & (1 << 3)) == 0) { // Line 3 is LOW
    for(int b=0; b<9; b++) if(keyMatrix[3][b]) target_directions_mask |= (1 << (10 + b));
  }
  if ((current_gpio & (1 << 4)) == 0) { // Line 4 is LOW
    for(int b=0; b<9; b++) if(keyMatrix[4][b]) target_directions_mask |= (1 << (10 + b));
  }
  if ((current_gpio & (1 << 5)) == 0) { // Line 5 is LOW
    for(int b=0; b<9; b++) if(keyMatrix[5][b]) target_directions_mask |= (1 << (10 + b));
  }
  if ((current_gpio & (1 << 6)) == 0) { // Line 6 is LOW
    for(int b=0; b<9; b++) if(keyMatrix[6][b]) target_directions_mask |= (1 << (10 + b));
  }
  if ((current_gpio & (1 << 7)) == 0) { // Line 7 is LOW
    for(int b=0; b<9; b++) if(keyMatrix[7][b]) target_directions_mask |= (1 << (10 + b));
  }
  if ((current_gpio & (1 << 8)) == 0) { // Line 8 is LOW
    for(int b=0; b<9; b++) if(keyMatrix[8][b]) target_directions_mask |= (1 << (10 + b));
  }
  if ((current_gpio & (1 << 9)) == 0) { // Line 9 is LOW
    for(int b=0; b<9; b++) if(keyMatrix[9][b]) target_directions_mask |= (1 << (10 + b));
  }

  // --- NATIVE MASKED EXECUTION BLOCK ---
  // A master layout definition spanning across your 9 return data channels (GPIO 10 to 18)
  uint32_t data_bus_total_mask = (0x1FF << 10); 

  // Isolate which bits should be outputs vs which should float back to input inputs
  uint32_t output_mask = target_directions_mask & data_bus_total_mask;
  uint32_t input_mask  = (~target_directions_mask) & data_bus_total_mask;

  // Apply the raw directional properties to all data pins simultaneously
  gpio_set_dir_out_masked(output_mask);
  gpio_set_dir_in_masked(input_mask);
}

